//
// vm project
//

#include <dlfcn.h>
#include <vector>
#include <sstream>
#include <string>
#include "Boot.hh"

#include <iostream>

void VMP::Boot::split(std::string const& str, std::vector<std::string> &ret, const char delim = ' ') const
{
  std::istringstream ss(str);

  for (std::string tmp ; std::getline(ss, tmp, delim) ; ret.push_back(tmp));
}

VMP::Boot::Boot(char **env)
{
  for (unsigned int i = 0 ; env[i] ; i++)
    {
      std::vector<std::string> tmp;

      split(env[i], tmp);
      m_env[tmp[0]] = tmp[1];
    }

  for (auto p : m_env)
    {
      std::cout << p.first << " " << p.second << std::endl;
    }
}

VMP::ErrCode VMP::Boot::load(std::string const& path)
{
  void *handle;

  if ((handle = dlopen(path.c_str(), RTLD_LAZY | RTLD_GLOBAL)) == NULL)
    return (VMP::ErrCode::LIBERR);
}

bool	VMP::Boot::exec(VMP::ErrCode &err)
{
  err = m_core.exec(m_env);
  return (false);
}
