//
// vm project
//

#ifndef __VMP__BOOT_HH_
# define __VMP__BOOT_HH_

#include <map>
#include <string>
#include <memory>
#include <vector>
#include "IVM.hh"
#include "ErrCode.hh"

namespace VMP
{
  class Boot
  {
  public :
    Boot() = delete;
    Boot(char **env);
    Boot(Boot const&) = delete;
    ~Boot() = default;
    Boot &operator=(Boot const&) = delete;
    ErrCode load(std::string const&);
    bool exec(ErrCode &err);

  private :
    std::map<std::string, std::string> m_env;
    std::shared_ptr<IVM> m_core;
    void split(std::string const&, std::vector<std::string> &, const char) const;
  };
}

#endif // __VMP__BOOT_HH_
