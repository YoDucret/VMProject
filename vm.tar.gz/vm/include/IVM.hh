//
// vm project
//

#ifndef __VMP__IVM_HH_
# define __VMP__IVM_HH_

#include <map>
#include <string>

struct IVM
{
  virtual ~IVM() = default;
  virtual unsigned short exec(std::map<std::string, std::string> const&) = 0;
};

#endif // __VMP__IVM_HH_
